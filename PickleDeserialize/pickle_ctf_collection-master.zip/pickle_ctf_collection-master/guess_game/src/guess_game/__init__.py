banner = r'''
  ____                        ____                      
 / ___|_   _  ___  ___ ___   / ___| __ _ _ __ ___   ___ 
| |  _| | | |/ _ \/ __/ __| | |  _ / _` | '_ ` _ \ / _ \
| |_| | |_| |  __/\__ \__ \ | |_| | (_| | | | | | |  __/
 \____|\__,_|\___||___/___/  \____|\__,_|_| |_| |_|\___|


Rule:
    Guess my number!
    If you are right in every round,
    then I will give you flag.
'''

max_round = 10
number_range = 10

from guess_game.Game import Game

game = Game()
