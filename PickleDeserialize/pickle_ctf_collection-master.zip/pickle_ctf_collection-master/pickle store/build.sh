read flag
echo $flag > container/flag.txt